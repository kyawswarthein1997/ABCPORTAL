<!Doctype html>
    <head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> 

  <!-- Footer-->
  

  <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>" >

  <!-- Footer -->

 
        
    </head>

    <body>
    
    <!--Navigation Bar -->

    <nav class="navbar navbar-expand-lg navbar-light ">
  <a class="navbar-brand" href="<?php echo e(route('mainhome')); ?>">ABC JOBS</a>

  <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
   <ul class="nav navbar-nav navbar-right">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('register')); ?>"> <span class="glyphicon glyphicon-user"></span> Register</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href=""><span class="glyphicon glyphicon-log-in"></span> Login</a>
      </li>
    </ul>
  </div>
</nav>



  <!-- Navigation -->

  
        <!--content-->
        <?php echo $__env->yieldContent('content'); ?>

        <br>

<!-- Footer -->


<!-- Footer -->
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/nav.blade.php ENDPATH**/ ?>