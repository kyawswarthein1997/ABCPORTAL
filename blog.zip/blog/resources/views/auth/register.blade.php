@extends('layouts.app')

@section('content')
<script src="{{asset('js/validation.js')}}"></script>

<title> ABC Portal Register </title>

<style>
.error{
    color:red;
}
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
 
}
</style>

<script>
function validateForm() {
    var validinput=true;

    k = document.forms["kst"]["username"].value;
    if (k == "") {
        document.getElementById("err_username").innerHTML = "Please enter your Username ";
        validinput=false;
    }
    else{
           document.getElementById("err_username").innerHTML = "";
    }

    k = document.forms["kst"]["email"].value;
    if (k == "") {
        document.getElementById("err_email").innerHTML = "Please enter your Email ";
        validinput=false;
    }
    else{
           document.getElementById("err_email").innerHTML = "";
    }
    	
    k = document.forms["kst"]["password"].value;
    if (k == "") {
        document.getElementById("err_pwd").innerHTML = "Please enter your Password!";
        validinput=false;
    }
    else{
           document.getElementById("err_pwd").innerHTML = "";
    }

    

    k = document.forms["kst"]["password-confirm"].value;
        if (k == "") {
            document.getElementById("err_password-confirm").innerHTML = "Please enter your Confirm Password!";
            validinput=false;
        }
        else{
            document.getElementById("err_password-confirm").innerHTML = "";
        }

    
    

    return validinput;
}
function chkblnk(eid, errid)
{
	var t = document.getElementById(eid).value;
	if (t == "")
	{
		document.getElementById(errid).innerHTML = "You need to fill your required field";
	} 
	else 
	{
		document.getElementById(errid).innerHTML = "";
	}
}
function chkAplha(event, err) 
{
	if (!((event.which >= 65 && event.which <= 90) || (event.which >= 97 && event.which <= 122) || event.which == 0 || event.which == 8))
	{
		document.getElementById(err).innerHTML = "The name format is invalid!";
		return false;
	}


}

var check = function() {
    if (document.getElementById('password').value ==
        document.getElementById('password-confirm').value) {
        document.getElementById('message').style.color = 'green';
        document.getElementById('message').innerHTML = 'Matching';
    } else {
            document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Not Matching';
    }
}
</script>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Register') }}</div>

                <div class="card-body">
                    <form novalidate id="kst" method="POST" action="{{ route('register') }}" onsubmit="return validateForm()"  data-toggle="validator">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('User Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
                                <div class="error" id="err_username"></div>
                               
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                <div class="error" id="err_email"></div>
                            </div>
                        </div>
                        

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password" onkeyup='check();'>

                                <div class="error" id="err_pwd"></div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" onkeyup='check();'>
                                <div class="error" id="password-confirm"></div>  <span id='message'></span>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="footer">
<footer class="section footer-classic context-dark bg-image" style="background: #3354FF; color:white;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p>We are an award-winning creative agency, dedicated to the best result in web design, promotion, business consulting, and marketing.</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2019</span><span> </span><span>Kyaw Swar Thein</span><span>. </span><span>All Rights Reserved.</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>279 Anawratha Street, Pabedan Township, Yangon, Myanmar</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd>info@abc.com</dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd>+959-250-641-679
                </dd>
              </dl>
            </div>
            
          </div>
        </div>
</footer>
</div>
@endsection
