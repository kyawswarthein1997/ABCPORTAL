function validateForm() {
    var validinput=true;

    var k = document.forms["kst"]["firstname"].value;
    if (k == "") {
        document.getElementById("err_firstname").innerHTML = "Please enter your First Name";
        validinput=false;
    }
    else{
           document.getElementById("err_firstname").innerHTML = "";
    }


    k = document.forms["kst"]["lastname"].value;
    if (k == "") {
        document.getElementById("err_lastname").innerHTML = "Please enter your Last name!";
        validinput=false;
    }
    else{
           document.getElementById("err_lastname").innerHTML = "";
    }

    k = document.forms["kst"]["username"].value;
    if (k == "") {
        document.getElementById("err_username").innerHTML = "Please enter your Username ";
        validinput=false;
    }
    else{
           document.getElementById("err_username").innerHTML = "";
    }

    k = document.forms["kst"]["email"].value;
    if (k == "") {
        document.getElementById("err_email").innerHTML = "Please enter your Email ";
        validinput=false;
    }
    else{
           document.getElementById("err_email").innerHTML = "";
    }
    
    k = document.forms["kst"]["country"].value;
    if (k == "") {
        document.getElementById("err_country").innerHTML = "Please enter your Country Address!";
        validinput=false;
    }
    else{
           document.getElementById("err_country").innerHTML = "";
    }

    k = document.forms["kst"]["mobile"].value;
    if (k == "") {
        document.getElementById("err_mobile").innerHTML = "Please enter your Mobile Number!";
        validinput=false;
    }
    else{
           document.getElementById("err_mobile").innerHTML = "";
    }

	
    k = document.forms["kst"]["password"].value;
    if (k == "") {
        document.getElementById("err_pwd").innerHTML = "Please enter your Password!";
        validinput=false;
    }
    else{
           document.getElementById("err_pwd").innerHTML = "";
    }

    

    k = document.forms["kst"]["password-confirm"].value;
        if (k == "") {
            document.getElementById("err_password-confirm").innerHTML = "Please enter your Confirm Password!";
            validinput=false;
        }
        else{
            document.getElementById("err_password-confirm").innerHTML = "";
        }

    
    

    return validinput;
}
function chkblnk(eid, errid)
{
	var t = document.getElementById(eid).value;
	if (t == "")
	{
		document.getElementById(errid).innerHTML = "You need to fill your required field";
	} 
	else 
	{
		document.getElementById(errid).innerHTML = "";
	}
}
function chkAplha(event, err) 
{
	if (!((event.which >= 65 && event.which <= 90) || (event.which >= 97 && event.which <= 122) || event.which == 0 || event.which == 8))
	{
		document.getElementById(err).innerHTML = "The name format is invalid!";
		return false;
	}


}

var check = function() {
    if (document.getElementById('password').value ==
        document.getElementById('password-confirm').value) {
        document.getElementById('message').style.color = 'green';
        document.getElementById('message').innerHTML = 'Matching';
    } else {
            document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Not Matching';
    }
}