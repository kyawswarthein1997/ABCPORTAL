<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use Auth;
use Image;
use App\User;

class profileController extends Controller
{
    public function profile()
    {
        return view('profile', array('user' => Auth::user()));
    }
    public function update_image(Request $request)
    {
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            Image::make($image)->resize(300, 300)->save(public_path('/images/avatars/' . $filename));

            $user = Auth::user();
            $user->image = $filename;
            $user->save();
        }
        return view('profile', array('user' => Auth::user()));
    }

    public function update_user()
    {
        return view('update', array('user' => Auth::user()));
    }
    public function update(Request $request){
       $user=User::find(Auth::user()->id);
       if($user){
        $user->fname=$request['fname'];
        $user->lname=$request['lname'];
        $user->country=$request['country'];
        $user->address=$request['address'];


        $user->save();
       }
       else{
           return redirect() -> back;
       }
    }    
}
        
    

