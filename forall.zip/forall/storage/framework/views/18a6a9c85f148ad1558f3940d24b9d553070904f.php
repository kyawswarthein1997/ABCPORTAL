<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <title>ABC Jobs</title>
        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> 



  <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
}
.nav-item{
    display: flex; 
}
</style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="nav-item" href="<?php echo e(url('/')); ?>">
                    ABC Job Portal
                </a>
               

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-left">
                    

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="active" href="<?php echo e(route('login')); ?>"><span class="glyphicon glyphicon-log-in"></span>  <?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="active" href="<?php echo e(route('register')); ?>"><span class="glyphicon glyphicon-user"></span> <?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>

                        <li class="nav-item "> 
                                <a class="ative" href="<?php echo e(route('home')); ?>"> <?php echo e(__('Home')); ?>

                            </li>
                            
                        
                        
                        <li class="nav-item">
                                <form action="/search" method="POST" role="search">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="input-group">
                                        <input type="text" class="form-control" name="q" placeholder="Search users"> <span class="input-group-btn">
                                            <button type="submit" class="btn btn-default" >
                                                <span class="glyphicon glyphicon-search"></span>
                                            </button>
                                        </span>
                                    </div>
                                </form>
                        </li>
                        <li class="nav-item"> 
                            <a class="active" href="<?php echo e(url('/update')); ?>">
                                    <img src="/images/avatars/<?php echo e(Auth::user()->image); ?>" style="width:32px; height:32px; position:absolute; top:10px; left:10px; border-radius:50%"> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp&nbsp   
                                    <?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?> <span class="caret"></span>
                            </a>
                        </li>     
                            

                            
                           <li class="nav-item">
                            <a class="active" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <span class="glyphicon glyphicon-log-out"> <?php echo e(__('Logout')); ?>

                            </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                            </li>

                            
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        



    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\forproject\forall\resources\views/layouts/app.blade.php ENDPATH**/ ?>