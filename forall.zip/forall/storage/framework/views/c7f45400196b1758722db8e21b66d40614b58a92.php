<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
                <div class="container-fluid">
<div class="row">
<div class="col-sm-1 ">
  </div>
  <div class="col-sm-4 ">
  <h1 class="purposes">Our main purpose!!!</h1>
<p class="text-justify">You can connect with the other people and you can share your experience with the others.</p>  
  </div>
  <div class="col-sm-7">
  <img src="<?php echo e(asset('images/welcome.png')); ?>" class="rounded " alt="ABC JOBS" height="100%" width="100%" ></div>
</div>
</div>
<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">What process that the users can do??</h1>
  </div>
</div>
<div class="container mt-2">
<!--   <div class="card card-block mb-2">
    <h4 class="card-title">Card 1</h4>
    <p class="card-text">Welcom to bootstrap card styles</p>
    <a href="#" class="btn btn-primary">Submit</a>
  </div>   -->
  <div class="row">
    <div class="col-md-3 col-sm-6">
    <div class="card card-block">
    <img src="https://www.pageuppeople.com/wp-content/uploads/2017/03/Rockstar-Talent-Mobility-Blog-1.-Employee-lifecycle-700x350.jpg" class="image" alt="Photo of sunset">
        <h5 class="card-title mt-3 mb-3">Find jobs and Earn jobs</h5>
        <p class="card-text">THe users can find the jobs at the portal and the employers can post the jobs at the portal </p> 
  </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="card card-block">
    <img src="https://cdn-images-1.medium.com/max/1600/1*4qKIg1kcvQ8obONfBzYIDQ.jpeg" alt="Photo of sunset" class="image" >
        <h5 class="card-title  mt-3 mb-3">Sharing knowledge</h5>
        <p class="card-text">The users can share their knowledge with the others</p> 
  </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="card card-block">
    <img src=https://blog.techsoup.org/hs-fs/hubfs/Blog%20Images/201902/gdpr-2-inline.png?width=720&name=gdpr-2-inline.png" alt="Photo of sunset" class="image" >
        <h5 class="card-title  mt-3 mb-3">Group</h5>
        <p class="card-text">The users can create the group with their members or friends at the protal </p> 
  </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="card card-block">
    <img src="<?php echo e(asset('images/groupworking.jpg')); ?>" alt="Photo of sunset"class="image" >
        <h5 class="card-title  mt-3 mb-3">Connect with the others users </h5>
        <p class="card-text">The users can join the others users at the portal and can make a new friends 
  </div>
    </div>    
  </div>
</div>
<br>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forproject\thinzarwinluck\resources\views/welcome.blade.php ENDPATH**/ ?>