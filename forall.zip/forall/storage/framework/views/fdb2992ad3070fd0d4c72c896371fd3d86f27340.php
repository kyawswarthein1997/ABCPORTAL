<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-6">
            <img src="/images/avatars/<?php echo e($user->image); ?>" style="width:150px; height=150px; float:left; border-radius:50%; margin-right:25px">
            <form action="/user_update">
            <h5>
                <label>Name:</label>
            <?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?> 
</h5>
<h5>
<label>Email:</label>

    <?php echo e($user->email); ?>

</h5>
<input type="submit" value="update your profile">
            </form>
            <form enctype="multipart/form-data" action="/profile" method="POST">
        <label>Upload your image</label>
        <input type="file" name="image">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="submit" class="pull-right btn btn-sm btn-primary">
        </form>
            
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\forproject\forall\resources\views/profile.blade.php ENDPATH**/ ?>