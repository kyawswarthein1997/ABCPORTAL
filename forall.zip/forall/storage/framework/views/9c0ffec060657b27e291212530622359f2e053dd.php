<div class="jumbotron text-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Please check your email</strong> for further instructions on how to complete your account setup.</p>
  <hr>
  <p>
    Having trouble? <a href="">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="/login" role="button">Continue</a>
  </p>
</div><?php /**PATH C:\xampp\htdocs\forproject\forall\resources\views/thank.blade.php ENDPATH**/ ?>