<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\profileController;
use App\User;
use Illuminate\Http\Request;
Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/thank', 'HomeController@thank')->name('thank');
Route::get('/login', 'HomeController@login')->name('login');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
 Auth::routes(['verify' => true]); 
Route::get('/home', 'HomeController@index')->name('home');

Route::get('update', 'profileController@profile');
Route::post('profile', 'profileController@update_image');
Route::get('user_update','profileController@update_user');
Route::post('update','profileController@update');
Route::any('/search',function(){
    $q = Request('q');
    $user = User::where('fname','LIKE','%'.$q.'%')
    ->orWhere('email','LIKE','%'.$q.'%')
    ->orWhere('address','LIKE','%'.$q.'%')
    ->orWhere('country','LIKE','%'.$q.'%')
    ->get();
    if(count($user) > 0)
        return view('sresult')->withDetails($user)->withQuery ( $q );
    else return view ('sresult')->withMessage('No Details found. Try to search again !');
});