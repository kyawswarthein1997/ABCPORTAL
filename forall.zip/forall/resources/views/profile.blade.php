@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-sm-1"></div>
        <div class="col-sm-6">
            <img src="/images/avatars/{{$user->image}}" style="width:150px; height=150px; float:left; border-radius:50%; margin-right:25px">
            <form action="/user_update">
            <h5>
                <label>Name:</label>
            {{ Auth::user()->fname}} {{ Auth::user()->lname}} 
</h5>
<h5>
<label>Email:</label>

    {{$user->email}}
</h5>
<input type="submit" value="update your profile">
            </form>
            <form enctype="multipart/form-data" action="/profile" method="POST">
        <label>Upload your image</label>
        <input type="file" name="image">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <input type="submit" class="pull-right btn btn-sm btn-primary">
        </form>
            
        </div>
    </div>
</div>
    @endsection