@extends('layouts.app')

@section('content')
  <div class="jumbotron text-center">
    <h1 class="display-3">Thank You!</h1>
    <p class="lead"><strong>Please check your email</strong> for further instructions on how to complete your account setup.</p>
    <hr>
    <p>
      Having trouble? <a href="">Contact us</a>
    </p>
    <p class="lead">
      <a class="btn btn-primary btn-sm" href="/login" role="button">Continue</a>
    </p>
  </div>

  <footer class="section footer-classic context-dark bg-image" style="background: #3354FF; color:white;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p>We are an award-winning creative agency, dedicated to the best result in web design, promotion, business consulting, and marketing.</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2019</span><span> </span><span>Kyaw Swar Thein</span><span>. </span><span>All Rights Reserved.</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>279 Anawratha Street, Pabedan Township, Yangon, Myanmar</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd>info@abc.com</dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd>+959-250-641-679
                </dd>
              </dl>
            </div>
            
          </div>
        </div>
</footer>
@endsection