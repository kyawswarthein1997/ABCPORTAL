<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Home Page</title>

    </head>
@extends('layouts.app')

@section('content')
<title> ABC Home Page </title>
<link href="{{ asset('css/newhome.css') }}" rel="stylesheet">

<!-- Hero Banner-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<!-- Hero Banner-->
    <body>
        <div class="flex-center position-ref full-height">
            <div class="content">
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="{{asset('img/Job-Search-SB.jpg')}}" alt="Los Angeles"  style="width:100%; height:80%; ">
      </div>
      <div class="item">
        <img src="{{asset('img/job-seeker.jpg')}}" alt="New York" style="width:100%; height:80%;" >
      </div>
      <div class="item">
        <img src="{{asset('img/germs_smaller.gif')}}" alt="New York" style="width:100%; height:80%; " >
      </div>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
</div>
</center>
<!-- Hero Banner-->
<br>
<div class="container">
<!-- Container (Services Section) -->
<div class="container-fluid text-center">
  <h2>SERVICES</h2>
  <h4>Why Choose Us?</h4>
  <br>
  <div class="row">
    <div class="col-sm-3">
      <img src="{{asset('img/2.jpg')}}" height="80px" width="80px" >
      <h4>Easy To Manage Jobs</h4>
      <p>A single, easy to navigate design helps you quickly connect with candidates</p>
    </div>
    <div class="col-sm-3">
    <img src="{{asset('img/1.png')}}" height="80px" width="120px" >
      <h4>Search Millions of Jobs</h4>
      <p> ABC analytics help you continuously understand which company engage with your outreach.</p>
    </div>
    <div class="col-sm-3">
    <img src="{{asset('img/images (1).png')}}" height="80px" width="80px" >
      <h4>Top Careers</h4>
      <p> Learn & Earn Process happen in your job carrers field which help you to develop your skills and knowledge. </p>
    </div>
    <div class="col-sm-3">
    <img src="{{asset('img/canidates-blue.png')}}" height="80px" width="80px" >
      <h4>Search Expert Candidates</h4>
      <p>Find candidates who match your requirement with precise filters to widen or narrow your search </p>
</div>
</div>
<!-- Container (Services Section) -->
 <hr>
<!--  -->

<div class="row">
    <div class="col-sm-8">
      <h2>Advantage of Conencting with ABC Job Portal</h2>  
      <p>Technology has changed the way job seekers search for jobs and employers find qualified employees. While employers still advertise job openings through traditional advertising mediums, such as local newspapers and magazines, today employers and job seekers turn to online job portals to find employment matches. Job seekers can advertise their skills and search for available positions, and employers can announce employment openings through our ABC Job Portal, for your dream job.</p>
    </div>
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-signal logo"></span>
    </div>
  </div>
</div>

 <hr>

  <div class="row">
    <div class="col-sm-4">
      <span class="glyphicon glyphicon-globe logo"></span>
    </div>
    <div class="col-sm-8">
      <h2>Our Values</h2>
      <h4><strong>MISSION:</strong> We create and deliver the best recruiting media, technologies and platforms for connecting jobs and people; we strive every day to help our customers hire and help people find jobs. </h4>      
      <h4><strong>VISION:</strong> ABC Job Poral will be the leading global talent platform connecting jobs and people</h4>
    </div>
  </div>
<hr>

<div class="jumbotron text-center">
  <h1>ABC Portal</h1> 
  <p>We specialize in Connecting Jobs</p> 
  <form>
    <div class="input-group">
      <input type="email" class="form-control" size="50" placeholder="Email Address" required>
      <div class="input-group-btn">
        <button type="button" class="btn btn-primary">Subscribe</button>
      </div>
    </div>
  </form>
</div>


</div> <!--Container Fluid--> 
</div>
            </div>
        </div>
    </body>

    <footer class="section footer-classic context-dark bg-image" style="background: #3354FF; color:white;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <p>We are an award-winning creative agency, dedicated to the best result in web design, promotion, business consulting, and marketing.</p>
                <!-- Rights-->
                <p class="rights"><span>©  </span><span class="copyright-year">2019</span><span> </span><span>Kyaw Swar Thein</span><span>. </span><span>All Rights Reserved.</span></p>
              </div>
            </div>
            <div class="col-md-4">
              <h5>Contacts</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>279 Anawratha Street, Pabedan Township, Yangon, Myanmar</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd>info@abc.com</dd>
              </dl>
              <dl class="contact-list">
                <dt>phones:</dt>
                <dd>+959-250-641-679
                </dd>
              </dl>
            </div>
            
          </div>
        </div>
</footer>
@endsection
</html>
