function validationForm() {

    var name = document.getElementById("email").value;
    var password = document.getElementById("password-box").value;
  
    if (name == "" && password == "") {
      document.getElementById("password-error").innerHTML = "*Please fill the Password";
      document.getElementById("email-error").innerHTML = "*Please fill the valid email";
      return false;
    } else {
      document.getElementById("email-error").innerHTML = "";
    }
  
    if (password == "") {
      document.getElementById("password-error").innerHTML = "*Please fill the Password";
      return false;
    } else {
      document.getElementById("password-error").innerHTML = "";
    }
  
  }